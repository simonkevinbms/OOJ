#include <stdio.h>
void main()
{
    int a[20],sum=0,n,*b,i;
    b=&a;
    printf("Enter number of elements:\n");
    scanf("%d",&n);
    for (i=0;i<n;i++)
        scanf("%d",(b+i));
    for (i=0;i<n;i++)
        sum+=*(b+i);
    printf("Sum=%d",sum);
}
