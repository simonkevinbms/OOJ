#include <stdio.h>
void swap (int *a,int *b)
{
    int t=*a;
    *a=*b;
    *b=t;
}
void main()
{
    int x,y;
    printf("Enter the two numbers :\n");
    scanf("%d%d",&x,&y);
    printf("Before swapping x=%d y=%d\n",x,y);
    swap(&x,&y);
    printf("After swapping x=%d y=%d",x,y);
}
