#include <stdio.h>
void main()
{
    int a[20],ele,pos=-1,i;
    printf("Enter number of elements:\n");
    scanf("%d",&n);
    printf("Enter the elements:\n");
    for (i=0;i<n;i++)
        scanf("%d",&a[i]);
    for (i=0;i<n;i++)
    {
        if (ele==a[i])
        {
            pos=i;
            break;
        }
    }
    if(pos)
}
