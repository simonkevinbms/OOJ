#include <stdio.h>
struct student{
    char id[10];
    int age;
    float marks;
   }s1;

void valid(struct student stud)
{
    if (stud.marks>=0 && stud.marks<=100 && stud.age>20)
            printf("The student is valid\n");
    else
        printf("The student is not valid\n");
}
void check(struct student stud)
{
    if(stud.marks>=65)
             printf("The student is eligible for admission in the university\n");
    else
        printf("The student is not eligible for admission in the university\n");
}
void main()
{

   printf("Enter student id,age and marks:\n");
   scanf("%s%d%f",s1.id,&s1.age,&s1.marks);
   valid(s1);
   check(s1);
}
