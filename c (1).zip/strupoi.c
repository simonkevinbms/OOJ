#include <stdio.h>
struct student
{
    char name[10];
    int age;
    float perc;
}s1;
void main()
{
  struct student *s;
  s=&s1;
  printf("Enter the name,age,perc:");
  scanf("%s%d%f",s->name,&s->age,&s->perc);
  printf("Name:%s\nAge:%d\nPercentage:%f",s->name,s->age,s->perc);
}
