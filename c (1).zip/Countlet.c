#include <stdio.h>
#include <ctype.h>
void main()
{
    char s[20],*p;
    int i,vow=0,con=0;
    p=&s;
    printf("Enter the string:\n");
    gets(s);
    for(i=0;i<strlen(s);i++)
    {
        if ((*(p+i)>='a' && *(p+i)<='z') || (*(p+i)>='A' && *(p+i)<='Z'))
            if (*(p+i)=='a' || *(p+i)=='e' || *(p+i)=='i' || *(p+i)=='o' || *(p+i)=='u' ||*(p+i)=='A' || *(p+i)=='E' || *(p+i)=='I' || *(p+i)=='O' || *(p+i)=='U')
                vow+=1;
            else
                con+=1;
    }
    printf("The number of vowels :%d\nThe number of consonants:%d",vow,con);
}
